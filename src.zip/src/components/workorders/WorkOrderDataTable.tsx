"use client";

import * as React from "react";

import {
  Eye,
  Plus,
} from "lucide-react";

import {
  useRouter,
} from "next/navigation";

import { toast } from "sonner";

import { Button } from "@/components/ui/button";

import type {
  WorkOrderListItem,
} from "@/app/(private)/workorders/actions";

import WorkOrderDataTable from "@/WorkOrderDataTable";

import {
  filterWorkOrders,
} from "./work-order-table.helpers";

export default function WorkOrderTable({
  initialData,
  initialStatus = "",
  initialScheduledDate = "",
  created = false,
}: {
  initialData:
    WorkOrderListItem[];
  initialStatus?: string;
  initialScheduledDate?: string;
  created?: boolean;
}) {
  const router =
    useRouter();

  const [
    rows,
    setRows,
  ] = React.useState(
    initialData,
  );

  const [
    search,
    setSearch,
  ] = React.useState("");

  React.useEffect(() => {
    setRows(initialData);
  }, [initialData]);

  React.useEffect(() => {
    if (created) {
      toast.success(
        "Ordem de serviço criada com sucesso.",
      );

      router.replace(
        "/workorders",
        {
          scroll: false,
        },
      );
    }
  }, [
    created,
    router,
  ]);

  const filteredRows =
    React.useMemo(() => {
      let result =
        filterWorkOrders(
          rows,
          search,
        );

      if (initialStatus) {
        const normalizedStatus =
          initialStatus
            .replace(
              /[_\s-]/g,
              "",
            )
            .toUpperCase();

        result = result.filter(
          (order) =>
            String(
              order.status,
            )
              .replace(
                /[_\s-]/g,
                "",
              )
              .toUpperCase() ===
            normalizedStatus,
        );
      }

      if (
        initialScheduledDate
      ) {
        result = result.filter(
          (order) =>
            order.scheduledDate
              ?.slice(0, 10) ===
            initialScheduledDate,
        );
      }

      return result;
    }, [
      initialScheduledDate,
      initialStatus,
      rows,
      search,
    ]);

  return (
    <WorkOrderDataTable
      title="Todas as Ordens de Serviço"
      description={`${filteredRows.length} ${
        filteredRows.length === 1
          ? "ordem encontrada"
          : "ordens encontradas"
      }.`}
      orders={filteredRows}
      search={search}
      onSearchChange={setSearch}
      searchPlaceholder="Buscar cliente, título, status ou endereço..."
      emptyTitle="Nenhuma ordem encontrada"
      emptyDescription="Não existem ordens correspondentes à pesquisa atual."
      headerAction={
        <Button
          type="button"
          className="btn-brand h-10 rounded-xl px-4 text-white"
          onClick={() =>
            router.push(
              "/workorders/new",
            )
          }
        >
          <Plus className="mr-2 h-4 w-4" />

          Nova OS
        </Button>
      }
      renderAction={(order) => (
        <Button
          type="button"
          variant="outline"
          size="sm"
          className="h-8 rounded-lg px-3 text-xs"
          onClick={() =>
            router.push(
              `/workorders/${order.id}`,
            )
          }
        >
          <Eye className="mr-1.5 h-3.5 w-3.5" />

          Detalhes
        </Button>
      )}
    />
  );
}