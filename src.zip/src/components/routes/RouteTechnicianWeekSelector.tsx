"use client";

import {
  ChevronRight,
  UserRound,
} from "lucide-react";

import type {
  TechnicianWeekMetric,
} from "./routeWeek.utils";

import {
  technicianInitials,
} from "./routeWeek.utils";

type TechnicianRouteCardProps = {
  name: string;
  selected?: boolean;
  metric: TechnicianWeekMetric;
  onClick: () => void;
};

export default function TechnicianRouteCard({
  name,
  selected = false,
  metric,
  onClick,
}: TechnicianRouteCardProps) {
  const progressLabel =
    metric.orders > 0
      ? `${metric.completed}/${metric.orders} concluídos`
      : "Sem atendimentos na semana";

  return (
    <button
      type="button"
      onClick={onClick}
      className={`
        group w-full rounded-2xl border bg-white p-4 text-left transition
        ${
          selected
            ? "border-sky-400 ring-2 ring-sky-100"
            : "border-slate-200 hover:border-sky-200 hover:shadow-sm"
        }
      `}
    >
      <div className="flex items-start gap-3">
        <div
          className={`
            grid h-10 w-10 shrink-0 place-items-center rounded-xl text-xs font-bold
            ${
              selected
                ? "bg-sky-600 text-white"
                : "bg-sky-50 text-sky-700"
            }
          `}
        >
          {technicianInitials(name)}
        </div>

        <div className="min-w-0 flex-1">
          <div className="flex items-start justify-between gap-2">
            <div className="min-w-0">
              <div className="truncate text-sm font-bold text-slate-900">
                {name}
              </div>

              <div className="mt-1 flex items-center gap-1.5 text-xs text-slate-500">
                <UserRound className="h-3.5 w-3.5" />

                <span>
                  {metric.orders}{" "}
                  {metric.orders === 1
                    ? "atendimento"
                    : "atendimentos"}{" "}
                  na semana
                </span>
              </div>

              <div className="mt-1 text-xs text-slate-400">
                {metric.routes}{" "}
                {metric.routes === 1
                  ? "dia com rota"
                  : "dias com rota"}
              </div>
            </div>

            <ChevronRight
              className={`
                mt-1 h-4 w-4 shrink-0 transition
                ${
                  selected
                    ? "text-sky-600"
                    : "text-slate-300 group-hover:text-sky-500"
                }
              `}
            />
          </div>

          <span className="mt-3 inline-flex rounded-full border border-slate-200 bg-slate-50 px-2.5 py-1 text-[10px] font-semibold text-slate-600">
            {progressLabel}
          </span>
        </div>
      </div>
    </button>
  );
}