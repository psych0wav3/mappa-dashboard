"use client";

import * as React from "react";

import {
  useRouter,
} from "next/navigation";

import {
  ArrowDown,
  ArrowLeft,
  ArrowUp,
  CheckCircle2,
  GripVertical,
  ListOrdered,
  MapPin,
  Plus,
  Route,
  Save,
  Search,
  Sparkles,
  Trash2,
} from "lucide-react";

import {
  toast,
} from "sonner";

import {
  createRouteFromPlanner,
  type AvailableRouteWorkOrder,
  type RouteDashboardItem,
  type RouteTechnicianOption,
} from "@/app/(private)/routes/actions";

import RouteMapPanel from "@/components/routes/RouteMapPanel";

import RouteTechnicianWeekSelector from "@/components/routes/RouteTechnicianWeekSelector";

import {
  addDays,
  formatDate,
  getTechnicianDayMeta,
  getTechnicianRouteForDate,
  getTechnicianWeekMetrics,
  routeStatusClass,
  routeStatusLabel,
  startOfWeekMonday,
  toIsoDate,
} from "@/components/routes/routeWeek.utils";

import {
  Button,
} from "@/components/ui/button";

import {
  Input,
} from "@/components/ui/input";

type RouteBuilderProps = {
  technicians: RouteTechnicianOption[];
  initialOrders: AvailableRouteWorkOrder[];
  initialRoutes: RouteDashboardItem[];
};

function normalizeText(
  value?: string | null,
) {
  return String(value || "")
    .trim()
    .toLocaleLowerCase(
      "pt-BR",
    );
}

function belongsToTechnician(
  order: AvailableRouteWorkOrder,
  technician: RouteTechnicianOption,
) {
  if (order.technicianId) {
    return (
      order.technicianId ===
      technician.id
    );
  }

  if (order.technicianName) {
    return (
      normalizeText(
        order.technicianName,
      ) ===
      normalizeText(
        technician.name,
      )
    );
  }

  return false;
}

function isUnassigned(
  order: AvailableRouteWorkOrder,
) {
  return (
    !order.technicianId &&
    !order.technicianName
  );
}

function routeTitle(
  date: string,
  technicianName: string,
) {
  const weekday = new Date(
    `${date}T12:00:00`,
  ).toLocaleDateString(
    "pt-BR",
    {
      weekday: "long",
    },
  );

  const capitalized =
    weekday
      .charAt(0)
      .toUpperCase() +
    weekday.slice(1);

  return `Rota de ${capitalized} — ${technicianName}`;
}

function SelectedStopCard({
  order,
  position,
  isFirst,
  isLast,
  onMoveUp,
  onMoveDown,
  onRemove,
}: {
  order: AvailableRouteWorkOrder;
  position: number;
  isFirst: boolean;
  isLast: boolean;
  onMoveUp: () => void;
  onMoveDown: () => void;
  onRemove: () => void;
}) {
  return (
    <article className="rounded-xl border border-slate-200 bg-white p-3.5">
      <div className="flex items-start gap-3">
        <div className="flex shrink-0 items-center gap-2">
          <GripVertical className="h-5 w-5 text-slate-300" />

          <div className="grid h-9 w-9 place-items-center rounded-xl bg-sky-600 text-sm font-bold text-white">
            {position}
          </div>
        </div>

        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <h3 className="truncate text-sm font-bold text-slate-900">
              {
                order.customerName
              }
            </h3>

            {typeof order.orderNumber ===
              "number" && (
              <span className="rounded-full border border-slate-200 bg-slate-50 px-2 py-0.5 text-[10px] font-semibold text-slate-600">
                OS{" "}
                {
                  order.orderNumber
                }
              </span>
            )}
          </div>

          <p className="mt-0.5 truncate text-xs font-medium text-slate-600">
            {order.title}
          </p>

          <div className="mt-2 flex items-start gap-1.5 text-xs leading-5 text-slate-500">
            <MapPin className="mt-0.5 h-3.5 w-3.5 shrink-0 text-sky-600" />

            <span>
              {order.address}
            </span>
          </div>
        </div>

        <div className="flex shrink-0 items-center gap-1">
          <Button
            type="button"
            variant="outline"
            size="sm"
            className="h-8 w-8 rounded-lg p-0"
            onClick={
              onMoveUp
            }
            disabled={
              isFirst
            }
            title="Mover para cima"
          >
            <ArrowUp className="h-3.5 w-3.5" />
          </Button>

          <Button
            type="button"
            variant="outline"
            size="sm"
            className="h-8 w-8 rounded-lg p-0"
            onClick={
              onMoveDown
            }
            disabled={
              isLast
            }
            title="Mover para baixo"
          >
            <ArrowDown className="h-3.5 w-3.5" />
          </Button>

          <Button
            type="button"
            variant="outline"
            size="sm"
            className="h-8 w-8 rounded-lg border-red-200 p-0 text-red-600 hover:bg-red-50 hover:text-red-700"
            onClick={
              onRemove
            }
            title="Remover da rota"
          >
            <Trash2 className="h-3.5 w-3.5" />
          </Button>
        </div>
      </div>
    </article>
  );
}

function AvailableOrderCard({
  order,
  onAdd,
}: {
  order: AvailableRouteWorkOrder;
  onAdd: () => void;
}) {
  return (
    <article className="rounded-xl border border-slate-200 bg-white p-3.5">
      <div className="flex items-start gap-3">
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <h3 className="truncate text-sm font-bold text-slate-900">
              {
                order.customerName
              }
            </h3>

            {typeof order.orderNumber ===
              "number" && (
              <span className="rounded-full border border-slate-200 bg-slate-50 px-2 py-0.5 text-[10px] font-semibold text-slate-600">
                OS{" "}
                {
                  order.orderNumber
                }
              </span>
            )}
          </div>

          <p className="mt-1 text-xs font-medium text-slate-600">
            {order.title}
          </p>

          <div className="mt-2 flex items-start gap-1.5 text-xs text-slate-500">
            <MapPin
              className={`
                mt-0.5 h-3.5 w-3.5 shrink-0
                ${
                  order.hasAddress
                    ? "text-sky-600"
                    : "text-amber-600"
                }
              `}
            />

            <span
              className={
                order.hasAddress
                  ? ""
                  : "font-medium text-amber-700"
              }
            >
              {order.hasAddress
                ? order.address
                : "Endereço pendente"}
            </span>
          </div>
        </div>

        <Button
          type="button"
          className="btn-brand h-9 shrink-0 rounded-xl px-3 text-xs text-white"
          onClick={onAdd}
          disabled={
            !order.hasAddress
          }
        >
          <Plus className="mr-1.5 h-3.5 w-3.5" />

          Adicionar
        </Button>
      </div>
    </article>
  );
}

export default function RouteBuilder({
  technicians,
  initialOrders,
  initialRoutes,
}: RouteBuilderProps) {
  const router =
    useRouter();

  const [
    pending,
    startTransition,
  ] = React.useTransition();

  const todayIso =
    React.useMemo(
      () =>
        toIsoDate(
          new Date(),
        ),
      [],
    );

  const currentWeekStart =
    React.useMemo(
      () =>
        toIsoDate(
          startOfWeekMonday(
            new Date(),
          ),
        ),
      [],
    );

  const [
    weekStartDate,
    setWeekStartDate,
  ] = React.useState(
    currentWeekStart,
  );

  const [
    selectedDate,
    setSelectedDate,
  ] = React.useState(
    todayIso,
  );

  const [
    technicianId,
    setTechnicianId,
  ] = React.useState(
    technicians[0]?.id ||
      "",
  );

  const [
    search,
    setSearch,
  ] = React.useState("");

  const [
    showMap,
    setShowMap,
  ] = React.useState(false);

  const [
    drafts,
    setDrafts,
  ] = React.useState<
    Record<string, string[]>
  >({});

  React.useEffect(() => {
    if (
      !technicianId &&
      technicians[0]?.id
    ) {
      setTechnicianId(
        technicians[0].id,
      );
    }
  }, [
    technicianId,
    technicians,
  ]);

  const selectedTechnician =
    React.useMemo(
      () =>
        technicians.find(
          (technician) =>
            technician.id ===
            technicianId,
        ) || null,
      [
        technicianId,
        technicians,
      ],
    );

  const technicianMetrics =
    React.useMemo(
      () =>
        getTechnicianWeekMetrics(
          technicians,
          initialRoutes,
          weekStartDate,
        ),
      [
        initialRoutes,
        technicians,
        weekStartDate,
      ],
    );

  const dayMeta =
    React.useMemo(
      () =>
        getTechnicianDayMeta(
          initialRoutes,
          technicianId,
          weekStartDate,
        ),
      [
        initialRoutes,
        technicianId,
        weekStartDate,
      ],
    );

  const existingRoute =
    React.useMemo(
      () =>
        getTechnicianRouteForDate(
          initialRoutes,
          technicianId,
          selectedDate,
        ),
      [
        initialRoutes,
        selectedDate,
        technicianId,
      ],
    );

  const orderMap =
    React.useMemo(
      () =>
        new Map(
          initialOrders.map(
            (order) => [
              order.id,
              order,
            ],
          ),
        ),
      [initialOrders],
    );

  /*
   * Se as OS do dia já estiverem
   * vinculadas ao técnico,
   * elas entram automaticamente
   * na montagem da rota.
   */
  const defaultSelectedIds =
    React.useMemo(() => {
      if (
        !selectedTechnician ||
        existingRoute
      ) {
        return [];
      }

      return initialOrders
        .filter(
          (order) =>
            order.scheduledDate ===
              selectedDate &&
            order.hasAddress &&
            belongsToTechnician(
              order,
              selectedTechnician,
            ),
        )
        .map(
          (order) =>
            order.id,
        );
    }, [
      existingRoute,
      initialOrders,
      selectedDate,
      selectedTechnician,
    ]);

  const draftKey =
    `${technicianId}:${selectedDate}`;

  const selectedIds =
    drafts[draftKey] ??
    defaultSelectedIds;

  const selectedOrders =
    React.useMemo(
      () =>
        selectedIds
          .map(
            (id) =>
              orderMap.get(
                id,
              ),
          )
          .filter(
            (
              order,
            ): order is AvailableRouteWorkOrder =>
              Boolean(order),
          ),
      [
        orderMap,
        selectedIds,
      ],
    );

  const availableOrders =
    React.useMemo(() => {
      if (
        !selectedTechnician ||
        existingRoute
      ) {
        return [];
      }

      const term =
        normalizeText(
          search,
        );

      return initialOrders.filter(
        (order) => {
          if (
            order.scheduledDate !==
            selectedDate
          ) {
            return false;
          }

          if (
            selectedIds.includes(
              order.id,
            )
          ) {
            return false;
          }

          const compatible =
            isUnassigned(
              order,
            ) ||
            belongsToTechnician(
              order,
              selectedTechnician,
            );

          if (!compatible) {
            return false;
          }

          if (!term) {
            return true;
          }

          return normalizeText(
            [
              order.customerName,
              order.title,
              order.description,
              order.address,
            ].join(" "),
          ).includes(term);
        },
      );
    }, [
      existingRoute,
      initialOrders,
      search,
      selectedDate,
      selectedIds,
      selectedTechnician,
    ]);

  function replaceDraft(
    next: string[],
  ) {
    setDrafts(
      (current) => ({
        ...current,

        [draftKey]:
          next,
      }),
    );
  }

  function selectTechnician(
    id: string,
  ) {
    setTechnicianId(id);
    setSearch("");
    setShowMap(false);
  }

  function moveOrder(
    index: number,
    direction: -1 | 1,
  ) {
    const targetIndex =
      index + direction;

    if (
      targetIndex < 0 ||
      targetIndex >=
        selectedIds.length
    ) {
      return;
    }

    const next = [
      ...selectedIds,
    ];

    [
      next[index],
      next[targetIndex],
    ] = [
      next[targetIndex],
      next[index],
    ];

    replaceDraft(next);
  }

  function addOrder(
    id: string,
  ) {
    if (
      !selectedIds.includes(
        id,
      )
    ) {
      replaceDraft([
        ...selectedIds,
        id,
      ]);
    }
  }

  function removeOrder(
    id: string,
  ) {
    replaceDraft(
      selectedIds.filter(
        (currentId) =>
          currentId !== id,
      ),
    );
  }

  function previousWeek() {
    const next = addDays(
      weekStartDate,
      -7,
    );

    setWeekStartDate(next);
    setSelectedDate(next);
    setShowMap(false);
  }

  function currentWeek() {
    setWeekStartDate(
      currentWeekStart,
    );

    setSelectedDate(
      todayIso,
    );

    setShowMap(false);
  }

  function nextWeek() {
    const next = addDays(
      weekStartDate,
      7,
    );

    setWeekStartDate(next);
    setSelectedDate(next);
    setShowMap(false);
  }

  async function optimizeSequence() {
    const stops =
      selectedOrders.filter(
        (order) =>
          order.hasCoordinates,
      );

    if (stops.length < 2) {
      toast.error(
        "É preciso ao menos 2 paradas com coordenadas para otimizar.",
      );

      return;
    }

    try {
      const response =
        await fetch(
          "/api/routes/optimize",
          {
            method: "POST",

            headers: {
              "Content-Type":
                "application/json",
            },

            body: JSON.stringify({
              startTime:
                "08:00",

              stops:
                stops.map(
                  (order) => ({
                    id:
                      order.id,

                    lat:
                      order.lat,

                    lng:
                      order.lng,

                    durationMin:
                      45,
                  }),
                ),
            }),
          },
        );

      const data =
        (await response.json()) as {
          order?: string[];
          error?: string;
        };

      if (
        !response.ok ||
        !data.order?.length
      ) {
        throw new Error(
          data.error ||
            "Não foi possível otimizar a sequência.",
        );
      }

      const withoutCoordinates =
        selectedIds.filter(
          (id) =>
            !stops.some(
              (stop) =>
                stop.id ===
                id,
            ),
        );

      replaceDraft([
        ...data.order,
        ...withoutCoordinates,
      ]);

      toast.success(
        "Sequência otimizada com base na localização.",
      );
    } catch (error) {
      toast.error(
        error instanceof Error
          ? error.message
          : "Não foi possível otimizar a sequência.",
      );
    }
  }

  function createDailyRoute() {
    if (
      !selectedTechnician
    ) {
      toast.error(
        "Selecione um técnico.",
      );

      return;
    }

    if (existingRoute) {
      toast.error(
        "Já existe uma rota para este técnico neste dia.",
      );

      return;
    }

    if (
      !selectedOrders.length
    ) {
      toast.error(
        "Adicione ao menos um atendimento à rota.",
      );

      return;
    }

    startTransition(
      async () => {
        const result =
          await createRouteFromPlanner(
            {
              title:
                routeTitle(
                  selectedDate,
                  selectedTechnician.name,
                ),

              routeDate:
                selectedDate,

              employeeUserId:
                selectedTechnician.id,

              serviceOrderIds:
                selectedOrders.map(
                  (order) =>
                    order.id,
                ),
            },
          );

        if (!result.ok) {
          toast.error(
            result.error ||
              "Não foi possível criar a rota.",
          );

          return;
        }

        toast.success(
          `Rota de ${formatDate(
            selectedDate,
          )} criada para ${
            selectedTechnician.name
          }.`,
        );

        setDrafts(
          (current) => {
            const next = {
              ...current,
            };

            delete next[
              draftKey
            ];

            return next;
          },
        );

        router.refresh();
      },
    );
  }

  return (
    <div className="mx-auto max-w-7xl space-y-5 pb-8">
      <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-start gap-3">
            <div className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-sky-50 text-sky-700">
              <Route className="h-5 w-5" />
            </div>

            <div>
              <h1 className="text-lg font-bold text-slate-900">
                Planejamento de
                rotas
              </h1>

              <p className="mt-1 text-sm text-slate-500">
                Crie e organize as
                rotas diárias de cada
                técnico.
              </p>
            </div>
          </div>

          <Button
            type="button"
            variant="outline"
            className="rounded-xl"
            onClick={() =>
              router.push(
                "/routes/dashboard",
              )
            }
          >
            <ArrowLeft className="mr-2 h-4 w-4" />

            Controle das rotas
          </Button>
        </div>
      </section>

      <RouteTechnicianWeekSelector
        technicians={
          technicians
        }
        technicianId={
          technicianId
        }
        technicianMetrics={
          technicianMetrics
        }
        weekStartDate={
          weekStartDate
        }
        selectedDate={
          selectedDate
        }
        todayIso={
          todayIso
        }
        dayMeta={
          dayMeta
        }
        onSelectTechnician={
          selectTechnician
        }
        onPreviousWeek={
          previousWeek
        }
        onCurrentWeek={
          currentWeek
        }
        onNextWeek={
          nextWeek
        }
        onSelectDate={(
          date,
        ) => {
          setSelectedDate(
            date,
          );

          setSearch("");

          setShowMap(false);
        }}
      />

      {selectedTechnician &&
      existingRoute ? (
        <section className="grid gap-5 xl:grid-cols-[1.05fr_0.95fr]">
          <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5">
            <div className="flex flex-col gap-3 border-b border-slate-100 pb-4 sm:flex-row sm:items-start sm:justify-between">
              <div>
                <div className="flex flex-wrap items-center gap-2">
                  <h2 className="text-base font-bold text-slate-900">
                    {
                      existingRoute.title
                    }
                  </h2>

                  <span
                    className={`
                      rounded-full border px-2.5 py-1 text-[10px] font-semibold
                      ${routeStatusClass(
                        existingRoute.status,
                      )}
                    `}
                  >
                    {routeStatusLabel(
                      existingRoute.status,
                    )}
                  </span>
                </div>

                <p className="mt-1 text-xs text-slate-500">
                  Já existe uma rota
                  criada para{" "}
                  {formatDate(
                    selectedDate,
                  )}
                  .
                </p>
              </div>

              <Button
                type="button"
                variant="outline"
                className="rounded-xl"
                onClick={() =>
                  router.push(
                    "/routes/dashboard",
                  )
                }
              >
                Abrir no controle
              </Button>
            </div>

            <div className="mt-4 space-y-2.5">
              {existingRoute.serviceOrders.map(
                (
                  order,
                  index,
                ) => (
                  <article
                    key={
                      order.id
                    }
                    className="rounded-xl border border-slate-200 bg-white p-3.5"
                  >
                    <div className="flex items-start gap-3">
                      <div className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-sky-600 text-xs font-bold text-white">
                        {index +
                          1}
                      </div>

                      <div className="min-w-0 flex-1">
                        <h3 className="truncate text-sm font-bold text-slate-900">
                          {
                            order.customerName
                          }
                        </h3>

                        <p className="mt-0.5 text-xs font-medium text-slate-600">
                          {
                            order.title
                          }
                        </p>

                        <div className="mt-2 flex items-start gap-1.5 text-xs text-slate-500">
                          <MapPin className="mt-0.5 h-3.5 w-3.5 shrink-0 text-sky-600" />

                          <span>
                            {
                              order.address
                            }
                          </span>
                        </div>
                      </div>
                    </div>
                  </article>
                ),
              )}
            </div>
          </div>

          <RouteMapPanel
            stops={
              existingRoute.serviceOrders
            }
            height={480}
          />
        </section>
      ) : selectedTechnician ? (
        <>
          <section className="grid gap-5 xl:grid-cols-[1.25fr_0.75fr]">
            <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5">
              <div className="flex flex-col gap-3 border-b border-slate-100 pb-4 sm:flex-row sm:items-start sm:justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <ListOrdered className="h-4 w-4 text-sky-600" />

                    <h2 className="text-sm font-semibold text-slate-900">
                      Montagem da
                      rota ·{" "}
                      {formatDate(
                        selectedDate,
                      )}
                    </h2>
                  </div>

                  <p className="mt-1 text-xs text-slate-500">
                    Adicione os
                    atendimentos e
                    organize a ordem
                    de execução.
                  </p>
                </div>

                <div className="flex flex-wrap gap-2">
                  <Button
                    type="button"
                    variant="outline"
                    className="h-9 rounded-xl px-3 text-xs"
                    onClick={
                      optimizeSequence
                    }
                    disabled={
                      pending ||
                      selectedOrders.filter(
                        (
                          order,
                        ) =>
                          order.hasCoordinates,
                      ).length <
                        2
                    }
                  >
                    <Sparkles className="mr-1.5 h-3.5 w-3.5" />

                    Otimizar
                  </Button>

                  <Button
                    type="button"
                    variant="outline"
                    className="h-9 rounded-xl px-3 text-xs"
                    onClick={() =>
                      setShowMap(
                        (
                          current,
                        ) =>
                          !current,
                      )
                    }
                  >
                    <MapPin className="mr-1.5 h-3.5 w-3.5" />

                    {showMap
                      ? "Ocultar mapa"
                      : "Ver mapa"}
                  </Button>
                </div>
              </div>

              <div className="mt-4 space-y-2.5">
                {selectedOrders.map(
                  (
                    order,
                    index,
                  ) => (
                    <SelectedStopCard
                      key={
                        order.id
                      }
                      order={
                        order
                      }
                      position={
                        index +
                        1
                      }
                      isFirst={
                        index ===
                        0
                      }
                      isLast={
                        index ===
                        selectedOrders.length -
                          1
                      }
                      onMoveUp={() =>
                        moveOrder(
                          index,
                          -1,
                        )
                      }
                      onMoveDown={() =>
                        moveOrder(
                          index,
                          1,
                        )
                      }
                      onRemove={() =>
                        removeOrder(
                          order.id,
                        )
                      }
                    />
                  ),
                )}

                {selectedOrders.length ===
                  0 && (
                  <div className="rounded-xl border border-dashed border-slate-300 bg-slate-50 px-5 py-10 text-center">
                    <ListOrdered className="mx-auto h-8 w-8 text-slate-300" />

                    <p className="mt-3 text-sm font-semibold text-slate-700">
                      Nenhum
                      atendimento
                      adicionado
                    </p>

                    <p className="mt-1 text-xs text-slate-400">
                      Use o painel
                      ao lado para
                      montar a rota
                      deste dia.
                    </p>
                  </div>
                )}
              </div>

              <div className="mt-4 flex flex-col gap-3 border-t border-slate-100 pt-4 sm:flex-row sm:items-center sm:justify-between">
                <div className="text-xs text-slate-500">
                  <strong className="text-slate-700">
                    {
                      selectedOrders.length
                    }
                  </strong>{" "}
                  {selectedOrders.length ===
                  1
                    ? "atendimento"
                    : "atendimentos"}{" "}
                  na rota
                </div>

                <Button
                  type="button"
                  className="btn-brand rounded-xl px-6 text-white"
                  onClick={
                    createDailyRoute
                  }
                  disabled={
                    pending ||
                    !selectedOrders.length
                  }
                >
                  <Save className="mr-2 h-4 w-4" />

                  {pending
                    ? "Criando rota..."
                    : "Criar rota"}
                </Button>
              </div>
            </div>

            <aside className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5">
              <div>
                <h2 className="text-sm font-semibold text-slate-900">
                  Atendimentos
                  disponíveis
                </h2>

                <p className="mt-1 text-xs leading-5 text-slate-500">
                  Adicione as OS
                  deste dia à rota
                  de{" "}
                  {
                    selectedTechnician.name
                  }
                  .
                </p>
              </div>

              <div className="relative mt-4">
                <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />

                <Input
                  value={
                    search
                  }
                  onChange={(
                    event,
                  ) =>
                    setSearch(
                      event
                        .target
                        .value,
                    )
                  }
                  placeholder="Buscar cliente ou serviço..."
                  className="h-10 rounded-xl pl-9"
                />
              </div>

              <div className="mt-4 max-h-[560px] space-y-2.5 overflow-y-auto pr-1">
                {availableOrders.map(
                  (
                    order,
                  ) => (
                    <AvailableOrderCard
                      key={
                        order.id
                      }
                      order={
                        order
                      }
                      onAdd={() =>
                        addOrder(
                          order.id,
                        )
                      }
                    />
                  ),
                )}

                {availableOrders.length ===
                  0 && (
                  <div className="rounded-xl border border-dashed border-slate-300 bg-slate-50 px-4 py-8 text-center">
                    <CheckCircle2 className="mx-auto h-7 w-7 text-emerald-500" />

                    <p className="mt-2 text-sm font-semibold text-slate-700">
                      Nenhum
                      atendimento
                      disponível
                    </p>

                    <p className="mt-1 text-xs text-slate-400">
                      Não há outras
                      OS compatíveis
                      com este
                      técnico e dia.
                    </p>
                  </div>
                )}
              </div>
            </aside>
          </section>

          {showMap && (
            <RouteMapPanel
              stops={
                selectedOrders
              }
              height={360}
            />
          )}
        </>
      ) : null}
    </div>
  );
}