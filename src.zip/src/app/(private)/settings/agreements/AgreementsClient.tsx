"use client";

import * as React from "react";
import { toast } from "sonner";
import { FileText, Plus, Power } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

import {
  createAgreement,
  listAgreementsAdmin,
  updateAgreementStatus,
  type Agreement,
} from "./actions";

function getErrorMessage(error: unknown, fallback: string) {
  if (error instanceof Error && error.message) return error.message;
  return fallback;
}

export default function AgreementsClient({
  initialAgreements,
}: {
  initialAgreements: Agreement[];
}) {
  const [items, setItems] = React.useState(initialAgreements);
  const [title, setTitle] = React.useState("");
  const [version, setVersion] = React.useState("1");
  const [content, setContent] = React.useState("");
  const [saving, setSaving] = React.useState(false);
  const [togglingId, setTogglingId] = React.useState<string | null>(null);

  const handleCreate = async () => {
    try {
      setSaving(true);
      const created = await createAgreement({ title, content, version });
      setItems((prev) => [created, ...prev]);
      setTitle("");
      setVersion("1");
      setContent("");
      toast.success("Termo criado.");
    } catch (error) {
      toast.error(getErrorMessage(error, "Não foi possível criar o termo."));
    } finally {
      setSaving(false);
    }
  };

  const handleToggle = async (agreement: Agreement) => {
    try {
      setTogglingId(agreement.id);
      const updated = await updateAgreementStatus({
        agreementId: agreement.id,
        isActive: !agreement.isActive,
      });
      setItems((prev) =>
        prev.map((item) => (item.id === updated.id ? updated : item)),
      );
      toast.success(
        updated.isActive ? "Termo ativado." : "Termo desativado.",
      );
    } catch (error) {
      toast.error(
        getErrorMessage(error, "Não foi possível atualizar o termo."),
      );
    } finally {
      setTogglingId(null);
    }
  };

  const refresh = async () => {
    try {
      const next = await listAgreementsAdmin(false);
      setItems(next);
    } catch (error) {
      toast.error(getErrorMessage(error, "Falha ao recarregar."));
    }
  };

  return (
    <div className="mx-auto flex w-full max-w-5xl flex-col gap-6">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold text-slate-900">
            Termos e acordos
          </h1>
          <p className="mt-1 text-sm text-slate-600">
            Termos globais da plataforma. Técnicos, clientes e admins precisam
            aceitar ao menos uma vez.
          </p>
        </div>
        <Button variant="outline" onClick={refresh}>
          Atualizar
        </Button>
      </div>

      <section className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
        <div className="mb-4 flex items-center gap-2 text-slate-900">
          <Plus className="h-4 w-4" />
          <h2 className="font-semibold">Novo termo</h2>
        </div>
        <div className="grid gap-3">
          <Input
            placeholder="Título"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />
          <Input
            placeholder="Versão (ex.: 1.0)"
            value={version}
            onChange={(e) => setVersion(e.target.value)}
          />
          <textarea
            className="min-h-40 w-full rounded-md border border-slate-200 px-3 py-2 text-sm outline-none focus:border-sky-500"
            placeholder="Conteúdo do termo"
            value={content}
            onChange={(e) => setContent(e.target.value)}
          />
          <div className="flex justify-end">
            <Button onClick={handleCreate} disabled={saving}>
              {saving ? "Salvando..." : "Publicar termo"}
            </Button>
          </div>
        </div>
      </section>

      <section className="grid gap-3">
        {items.length === 0 ? (
          <div className="rounded-xl border border-dashed border-slate-300 bg-white p-8 text-center text-sm text-slate-500">
            Nenhum termo cadastrado ainda.
          </div>
        ) : (
          items.map((item) => (
            <article
              key={item.id}
              className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-start gap-3">
                  <FileText className="mt-0.5 h-5 w-5 text-sky-700" />
                  <div>
                    <h3 className="font-semibold text-slate-900">
                      {item.title}
                    </h3>
                    <p className="text-xs text-slate-500">
                      Versão {item.version} ·{" "}
                      {item.isActive ? "Ativo" : "Inativo"}
                    </p>
                  </div>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  disabled={togglingId === item.id}
                  onClick={() => handleToggle(item)}
                >
                  <Power className="mr-1 h-3.5 w-3.5" />
                  {item.isActive ? "Desativar" : "Ativar"}
                </Button>
              </div>
              <p className="mt-3 whitespace-pre-wrap text-sm text-slate-700">
                {item.content}
              </p>
            </article>
          ))
        )}
      </section>
    </div>
  );
}
