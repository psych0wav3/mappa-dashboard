import type { Metadata } from "next";

import { listWorkOrders } from "../actions";
import ApprovedWorkOrdersClient from "./ApprovedWorkOrdersClient";

export const dynamic = "force-dynamic";
export const fetchCache = "force-no-store";

export const metadata: Metadata = {
  title: "Prontas para rota — Aqua Mappa",
};

export default async function ApprovedWorkOrdersPage() {
  const orders = await listWorkOrders({
    status: "WaitingExecution",
  });

  return (
    <div className="min-h-screen bg-neutral-50 px-4 py-6 sm:px-6 lg:px-8">
      <ApprovedWorkOrdersClient initialData={orders} />
    </div>
  );
}