import type {
  Metadata,
} from "next";

import {
  listApprovedServiceOrdersForRoute,
  listRouteTechnicians,
  listRoutesForDashboard,
} from "@/app/(private)/routes/actions";

import RouteBuilder from "@/components/routes/RouteBuilder";

export const dynamic =
  "force-dynamic";

export const fetchCache =
  "force-no-store";

export const metadata: Metadata = {
  title:
    "Planejamento de rotas — Aqua Mappa",
};

export default async function RouteBuilderPage() {
  const [
    technicians,
    availableOrders,
    routes,
  ] = await Promise.all([
    listRouteTechnicians(),

    listApprovedServiceOrdersForRoute(),

    listRoutesForDashboard(),
  ]);

  return (
    <div className="min-h-screen bg-neutral-50 px-4 py-6 sm:px-6 lg:px-8">
      <RouteBuilder
        technicians={
          technicians
        }
        initialOrders={
          availableOrders
        }
        initialRoutes={
          routes
        }
      />
    </div>
  );
}